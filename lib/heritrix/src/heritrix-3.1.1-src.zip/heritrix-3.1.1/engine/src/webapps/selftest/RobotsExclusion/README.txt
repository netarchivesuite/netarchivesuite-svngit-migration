The robots.txt that is used in this test actually lives in the root webapp.
It has to be there to it shows at the root of our host.
