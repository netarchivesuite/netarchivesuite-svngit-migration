/**
 * This package consists of modules that monitor an ongoing crawl by various means, 
 * typically interceding if certain limits/thresholds/conditions are met. 
 */
package org.archive.crawler.monitor;