import java.io.File;

import com.github.truemped.heritrix.HeritrixSession;
import com.github.truemped.heritrix.HeritrixSessionImpl;
import com.github.truemped.heritrix.HeritrixSessionInitializationException;


public class Test {

	public static void main(String[] args) {
		try {
			File ks = new File("C:\\Java\\heritrix-3.1.0\\conf\\h3.ks");
			HeritrixSession session = new HeritrixSessionImpl(ks, "h3", "localhost", 8443, "admin", "password");
			if (!session.jobExists("123456")) {
				session.createJob("123456");
				System.out.println("Job created.");
			}
			System.out.println( session.jobExists("123456") );
			System.out.println( session.isJobRunning("123456") );
			System.out.println( session.isPaused("123456"));
			System.out.println( session.jobExists("1234567") );
			System.out.println( session.isJobRunning("1234567") );
			System.out.println( session.isPaused("1234567"));
			System.out.println( session.jobExists("test") );
			System.out.println( session.isJobRunning("test") );
			System.out.println( session.isPaused("test"));
		} catch (HeritrixSessionInitializationException e) {
			e.printStackTrace();
		}
	}

}

