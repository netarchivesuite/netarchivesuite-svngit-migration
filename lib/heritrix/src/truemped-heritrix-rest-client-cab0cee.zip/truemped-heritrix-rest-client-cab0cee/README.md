Heritrix REST Client
====

This is a sample class for the Heritrix REST API. It is by no means a complete
implementation of the API. So feel free to fork this project and add the
missing API implementations.

License
===

Distributed under the terms of the MIT License (see LICENSE).
