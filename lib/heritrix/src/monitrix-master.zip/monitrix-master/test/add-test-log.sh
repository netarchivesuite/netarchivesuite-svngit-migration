curl --data "crawler_id=sample-log-1E3&path=$PWD/sample-log-1E3.txt" http://localhost:9000/admin/add-log
