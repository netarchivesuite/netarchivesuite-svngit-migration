Scripts for H3
--------------

Note that the version of Restlet used by H3 only supports application/x-www-form-urlencoded data. See
http://stackoverflow.com/questions/996819/restlet-how-to-process-multipart-form-data-requests

Note also that frontier-via-api depends on custom modifications to H3, and any that end in bsh are Bean Shell scripts that are
not currently supported by the launcher.

Some scripts sourced here:
https://webarchive.jira.com/wiki/display/Heritrix/Heritrix3+Useful+Scripts


