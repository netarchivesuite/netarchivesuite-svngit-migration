package uk.bl.monitrix.database;

import com.mongodb.DB;

public class ExtensionTable {
	
	public ExtensionTable(DB db) {	}

}
